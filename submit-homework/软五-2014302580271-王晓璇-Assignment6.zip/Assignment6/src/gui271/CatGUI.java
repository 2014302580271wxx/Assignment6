package gui271;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class CatGUI extends JFrame {
	//������ť
	public JButton c1;
	public JButton c2;
	public JButton c3;
	public JButton c4;
	public JButton c5;
	public JButton back;
	
	public CatGUI() {
		
		setLayout(new FlowLayout(FlowLayout.CENTER,150,75));
		
		//��������
		JFrame fcat=new JFrame("�ɰ�Сè");
		
		//��ťc1���벨˹è�������
		c1=new JButton("��˹è");
		add(c1);
		
		c1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new CatGUI().setVisible(false);
				Cat1 c1=new Cat1();
				c1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				c1.setSize(550,550);
				c1.setVisible(true);
			}
		});
		
		//��ťc2���벼żè����
		c2=new JButton("��żè");
		add(c2);
		
		c2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new CatGUI().setVisible(false);
				Cat2 c2=new Cat2();
				c2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				c2.setSize(550,550);
				c2.setVisible(true);
			}
		});
		
		//��ťc3���뻢��è����
		c3=new JButton("����è");
		add(c3);
		
		c3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new CatGUI().setVisible(false);
				Cat3 c3=new Cat3();
				c3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				c3.setSize(550,550);
				c3.setVisible(true);
			}
		});
		
		//��ťc4�����껨è����
		c4=new JButton("�껨è");
		add(c4);
		
		c4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new CatGUI().setVisible(false);
				Cat4 c4=new Cat4();
				c4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				c4.setSize(550,550);
				c4.setVisible(true);
			}
		});
		
		//��ťc5�����ո����۶�è����
		c5=new JButton("�ո����۶�è");
		add(c5);
		
		c5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new CatGUI().setVisible(false);
				Cat5 c5=new Cat5();
				c5.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				c5.setSize(550,550);
				c5.setVisible(true);
			}
		});
		
		//��ťback���س����̵����
		back=new JButton("����");
		add(back);
		
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new CatGUI().setVisible(false);
				MainpetGUI mp=new MainpetGUI();
				mp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				mp.setSize(550,550);
				mp.setVisible(true);
			}
		});
		
	}

}
