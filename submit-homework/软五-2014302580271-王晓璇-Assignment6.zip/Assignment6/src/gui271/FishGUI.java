package gui271;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class FishGUI extends JFrame {
	//������ť
	public JButton f1;
	public JButton f2;
	public JButton f3;
	public JButton f4;
	public JButton f5;
	public JButton back;
	
	public FishGUI() {
		
		setLayout(new FlowLayout(FlowLayout.CENTER,150,75));
		
		//��������
		JFrame ffish=new JFrame("�������");
		
		//��ťf1���뻢Ƥ��������
		f1=new JButton("��Ƥ��");
		add(f1);
		
		f1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new FishGUI().setVisible(false);
				Fish1 f1=new Fish1();
				f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				f1.setSize(550,550);
				f1.setVisible(true);
			}
		});
		
		//��ťf2�������������
		f2=new JButton("������");
		add(f2);
		
		f2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new FishGUI().setVisible(false);
				Fish2 f2=new Fish2();
				f2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				f2.setSize(550,550);
				f2.setVisible(true);
			}
		});
		
		//��ťf3����ˮ�ݽ������
		f3=new JButton("ˮ�ݽ���");
		add(f3);
		
		f3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new FishGUI().setVisible(false);
				Fish3 f3=new Fish3();
				f3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				f3.setSize(550,550);
				f3.setVisible(true);
			}
		});
		
		//��ťf4�������������
		f4=new JButton("������");
		add(f4);
		
		f4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new FishGUI().setVisible(false);
				Fish4 f4=new Fish4();
				f4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				f4.setSize(550,550);
				f4.setVisible(true);
			}
		});
		
		//��ťf5�����¹������
		f5=new JButton("�¹���");
		add(f5);
		
		f5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new FishGUI().setVisible(false);
				Fish5 f5=new Fish5();
				f5.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				f5.setSize(550,550);
				f5.setVisible(true);
			}
		});
		
		//��ťback���س����̵����
		back=new JButton("����");
		add(back);
		
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new FishGUI().setVisible(false);
				MainpetGUI mp=new MainpetGUI();
				mp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				mp.setSize(550,550);
				mp.setVisible(true);
			}
		});
		
	}

}