package gui271;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class BirdGUI extends JFrame {
	//������ť
	public JButton b1;
	public JButton b2;
	public JButton b3;
	public JButton b4;
	public JButton b5;
	public JButton back;
	
	
	public BirdGUI() {
		
		setLayout(new FlowLayout(FlowLayout.CENTER,150,75));
		
		//��������
		JFrame fbird=new JFrame("С����");
		
		//��ťb1���뻢Ƥ���ľ������
		b1=new JButton("��Ƥ����");
		add(b1);
		
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new BirdGUI().setVisible(false);
				Bird1 b1=new Bird1();
				b1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				b1.setSize(550,550);
				b1.setVisible(true);
			}
		});
		
		//��ťb2���뻭ü�����
		b2=new JButton("��ü��");
		add(b2);
		
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new BirdGUI().setVisible(false);
				Bird2 b2=new Bird2();
				b2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				b2.setSize(550,550);
				b2.setVisible(true);
			}
		});
		
		//��ťb3���������ݺ����
		b3=new JButton("������ݺ");
		add(b3);
		
		b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new BirdGUI().setVisible(false);
				Bird3 b3=new Bird3();
				b3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				b3.setSize(550,550);
				b3.setVisible(true);
			}
		});
		
		//��ťb4���뼦β���Ľ���
		b4=new JButton("��β����");
		add(b4);
		
		b4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new BirdGUI().setVisible(false);
				Bird4 b4=new Bird4();
				b4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				b4.setSize(550,550);
				b4.setVisible(true);
			}
		});
		
		//��ťb5�����˿ȸ����
		b5=new JButton("��˿ȸ");
		add(b5);
		
		b5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new BirdGUI().setVisible(false);
				Bird5 b5=new Bird5();
				b5.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				b5.setSize(550,550);
				b5.setVisible(true);
			}
		});
		
		//��ťback���س����̵����
		back=new JButton("����");
		add(back);
		
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new BirdGUI().setVisible(false);
				MainpetGUI mp=new MainpetGUI();
				mp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				mp.setSize(550,550);
				mp.setVisible(true);
			}
		});
		
	}

}
