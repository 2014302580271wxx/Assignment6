-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: test
-- ------------------------------------------------------
-- Server version	5.7.9-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `2014302580271_user`
--

LOCK TABLES `2014302580271_user` WRITE;
/*!40000 ALTER TABLE `2014302580271_user` DISABLE KEYS */;
INSERT INTO `2014302580271_user` VALUES (1,'波斯猫','喜温热食物','清水（充足清洁）','清洁安静的地方','舔毛（自我清洁），夜间活动',4200),(2,'布偶猫','猫粮','清水','室内（装备猫抓板）','抓挠，梳理毛发',10000),(3,'虎斑猫','罐头','清水','较空旷处','自我清洁，夜间活动',1600),(4,'狸花猫','猫粮','清水','室内','运动',3000),(5,'苏格兰折耳猫','猫粮','清水','室内','自我清洁，平躺睡觉',2000),(6,'虎皮鹦鹉','谷物蔬菜','清水','树干','模仿',100),(7,'画眉','鸡蛋，面包','清水','树干','鸣叫',100),(8,'黄腰柳莺','高热量动物性饲料','清水','树干','鸣叫',100),(9,'鸡尾鹦鹉','谷物','清水','树干','鸣叫',100),(10,'金丝雀','谷物','清水','树干','鸣叫',100),(11,'贵宾犬','肉，谷物，蔬菜','清水','空气流通，避免日晒的室内','运动',1500),(12,'哈士奇','肉，谷物，蔬菜','清水','宽敞地方','运动',1500),(13,'吉娃娃','肉，谷物，蔬菜','清水','温暖室内','运动',1500),(14,'金毛','肉，谷物，蔬菜','清水','干净犬舍','运动',1500),(15,'银狐犬','肉，谷物，蔬菜','清水','室内','吠叫',1500),(16,'虎皮鱼','红线虫，颗粒饲料','含氧量高的老水','含氧量高的老水','嬉水',5),(17,'玛丽鱼','草履虫，水蚯蚓','弱碱性硬水','弱碱性硬水','嬉水',10),(18,'水泡金鱼','红虫，水蚯蚓','淡水','浅水','嬉水',10),(19,'银龙鱼','泥鳅，小虾','弱酸性软水','弱酸性软水','嬉水',10),(20,'月光鱼','蛋黄，丰年虾','弱碱性水','弱碱性水','嬉水',10);
/*!40000 ALTER TABLE `2014302580271_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-12-06 21:57:39
