package gui271;

import sqlInformation.*;
import javax.swing.JFrame;

public class Main271 {
	public static void main(String[] args) {
		//��¼ҳ��
		LogInGUI log=new LogInGUI();
		log.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		log.setSize(500,500);
		log.setVisible(true);
		
	}

}
