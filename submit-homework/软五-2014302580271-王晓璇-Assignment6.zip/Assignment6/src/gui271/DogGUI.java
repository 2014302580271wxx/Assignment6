package gui271;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class DogGUI extends JFrame {
	//������ť
	public JButton d1;
	public JButton d2;
	public JButton d3;
	public JButton d4;
	public JButton d5;
	public JButton back;
	
	public DogGUI() {
		
		setLayout(new FlowLayout(FlowLayout.CENTER,150,75));
		
		//��������
		JFrame fdog=new JFrame("������Ȯ");
		
		//��ťd1������Ȯ�������
		d1=new JButton("���Ȯ");
		add(d1);
		
		d1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new DogGUI().setVisible(false);
				Dog1 d1=new Dog1();
				d1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				d1.setSize(550,550);
				d1.setVisible(true);
			}
		});
		
		//��ťd2�����ʿ�����
		d2=new JButton("��ʿ��");
		add(d2);
		
		d2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new DogGUI().setVisible(false);
				Dog2 d2=new Dog2();
				d2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				d2.setSize(550,550);
				d2.setVisible(true);
			}
		});
		
		//��ťd3���뼪���޽���
		d3=new JButton("������");
		add(d3);
		
		d3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new DogGUI().setVisible(false);
				Dog3 d3=new Dog3();
				d3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				d3.setSize(550,550);
				d3.setVisible(true);
			}
		});
		
		//��ťd4�����ë����
		d4=new JButton("��ë");
		add(d4);
		
		d4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new DogGUI().setVisible(false);
				Dog4 d4=new Dog4();
				d4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				d4.setSize(550,550);
				d4.setVisible(true);
			}
		});
		
		//��ťd5��������Ȯ����
		d5=new JButton("����Ȯ");
		add(d5);
		
		d5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new DogGUI().setVisible(false);
				Dog5 d5=new Dog5();
				d5.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				d5.setSize(550,550);
				d5.setVisible(true);
			}
		});
		
		//��ťback���س����̵����
		back=new JButton("����");
		add(back);
		
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new DogGUI().setVisible(false);
				MainpetGUI mp=new MainpetGUI();
				mp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				mp.setSize(550,550);
				mp.setVisible(true);
			}
		});
		
	}

}